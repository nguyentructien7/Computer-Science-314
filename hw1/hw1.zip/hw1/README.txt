
How to run those programs:
Select the folder
then type make then press enter. 
Then type ./p1 to run the problem 1
To run a different problem change the number 
For example ./p2 for problem 2

Number 10 is only partially done.